#include <stdio.h>
#define SIZE 10

int hashTable[SIZE];

void initialize() {
    for(int i = 0; i < SIZE; i++)
        hashTable[i] = -1;
}

int hash(int key) {
    return key % SIZE;
}

void insert(int key) {
    int index = hash(key);

    if(hashTable[index] == -1) {
        hashTable[index] = key;
    } else {
       
        int i = (index + 1) % SIZE;
        while(i != index && hashTable[i] != -1) {
            i = (i + 1) % SIZE;
        }

        if(i == index) {
            printf("Hash table is FULL\n");
        } else {
            hashTable[i] = key;
        }
    }
}

void display() {
    printf("Hash Table:\n");
    for(int i = 0; i < SIZE; i++) {
        if(hashTable[i] != -1)
            printf("%d --> %d\n", i, hashTable[i]);
        else
            printf("%d --> EMPTY\n", i);
    }
}

int main() {
    int n, value;

    initialize();

    printf("How many values to insert? ");
    scanf("%d", &n);

    for(int i = 0; i < n; i++) {
        printf("Enter value %d: ", i + 1);
        scanf("%d", &value);
        insert(value);
    }

    display();

    return 0;
}

