#include <stdio.h>
#define MAX 100
#define INF 9999

void dijkstra(int graph[MAX][MAX], int n, int start) {
    int distance[MAX];     // Stores shortest distance from start to i
    int visited[MAX];      // Keeps track of visited nodes
    int i, j, count, minDist, nextNode;

    // Initialization
    for (i = 0; i < n; i++) {
        distance[i] = graph[start][i];
        visited[i] = 0;
    }

    distance[start] = 0;
    visited[start] = 1;

    for (count = 1; count < n - 1; count++) {
        minDist = INF;
        
        // Find the unvisited node with the smallest distance
        for (i = 0; i < n; i++) {
            if (distance[i] < minDist && !visited[i]) {
                minDist = distance[i];
                nextNode = i;
            }
        }

        visited[nextNode] = 1;

        // Update distances of neighbors of the current node
        for (i = 0; i < n; i++) {
            if (!visited[i]) {
                if (minDist + graph[nextNode][i] < distance[i]) {
                    distance[i] = minDist + graph[nextNode][i];
                }
            }
        }
    }

    // Print the results
    printf("\nShortest distances from node %d:\n", start);
    for (i = 0; i < n; i++) {
        printf("To node %d = %d\n", i, distance[i]);
    }
}

int main() {
    int graph[MAX][MAX], n, i, j, start;

    printf("Enter number of nodes: ");
    scanf("%d", &n);

    printf("Enter adjacency matrix (use 9999 for no direct path):\n");
    for (i = 0; i < n; i++) {
        for (j = 0; j < n; j++) {
            scanf("%d", &graph[i][j]);
        }
    }

    printf("Enter starting node (0 to %d): ", n - 1);
    scanf("%d", &start);

    dijkstra(graph, n, start);

    return 0;
}


