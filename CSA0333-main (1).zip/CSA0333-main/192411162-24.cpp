#include <stdio.h>
#define MAX 100
#define INF 9999

void prim(int graph[MAX][MAX], int n) {
    int selected[MAX]; // Track selected vertices
    int i, j, edgeCount = 0;
    int min, x = 0, y = 0, totalCost = 0;

    // Initially, no vertices are selected
    for (i = 0; i < n; i++) {
        selected[i] = 0;
    }

    // Start from first vertex
    selected[0] = 1;

    printf("\nEdges in the Minimum Spanning Tree:\n");

    while (edgeCount < n - 1) {
        min = INF;

        for (i = 0; i < n; i++) {
            if (selected[i]) {
                for (j = 0; j < n; j++) {
                    if (!selected[j] && graph[i][j]) {
                        if (graph[i][j] < min) {
                            min = graph[i][j];
                            x = i;
                            y = j;
                        }
                    }
                }
            }
        }

        printf("%d - %d : Cost = %d\n", x, y, graph[x][y]);
        totalCost += graph[x][y];
        selected[y] = 1;
        edgeCount++;
    }

    printf("Total Cost of Minimum Spanning Tree: %d\n", totalCost);
}

int main() {
    int graph[MAX][MAX], n, i, j;

    printf("Enter number of nodes: ");
    scanf("%d", &n);

    printf("Enter adjacency matrix (use 9999 for no edge):\n");
    for (i = 0; i < n; i++) {
        for (j = 0; j < n; j++) {
            scanf("%d", &graph[i][j]);
        }
    }

    prim(graph, n);

    return 0;
}

