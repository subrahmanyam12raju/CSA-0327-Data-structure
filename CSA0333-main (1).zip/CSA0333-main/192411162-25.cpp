#include <stdio.h>

#define MAX 100
#define INF 9999

// Structure to represent an edge
struct Edge {
    int u, v, cost;
};

int parent[MAX];

// Function to find the parent of a node (with path compression)
int find(int i) {
    while (parent[i] != i)
        i = parent[i];
    return i;
}

// Function to union two sets
void unionSet(int i, int j) {
    int a = find(i);
    int b = find(j);
    parent[a] = b;
}

// Function to sort edges based on cost (ascending order)
void sortEdges(struct Edge edges[], int edgeCount) {
    int i, j;
    struct Edge temp;
    for (i = 0; i < edgeCount - 1; i++) {
        for (j = 0; j < edgeCount - i - 1; j++) {
            if (edges[j].cost > edges[j + 1].cost) {
                temp = edges[j];
                edges[j] = edges[j + 1];
                edges[j + 1] = temp;
            }
        }
    }
}

// Kruskal's algorithm
void kruskal(struct Edge edges[], int edgeCount, int n) {
    int i;
    int totalCost = 0;
    int edgeUsed = 0;

    // Initialize parent array
    for (i = 0; i < n; i++)
        parent[i] = i;

    // Sort edges by cost
    sortEdges(edges, edgeCount);

    printf("\nEdges in Minimum Spanning Tree:\n");
    for (i = 0; i < edgeCount; i++) {
        int u = edges[i].u;
        int v = edges[i].v;
        int cost = edges[i].cost;

        // If including this edge doesn't form a cycle
        if (find(u) != find(v)) {
            printf("%d - %d : Cost = %d\n", u, v, cost);
            totalCost += cost;
            unionSet(u, v);
            edgeUsed++;
        }

        if (edgeUsed == n - 1)
            break;
    }

    printf("Total Cost of Minimum Spanning Tree: %d\n", totalCost);
}

int main() {
    int n, i, j, edgeCount = 0;
    int graph[MAX][MAX];
    struct Edge edges[MAX * MAX];

    printf("Enter number of nodes: ");
    scanf("%d", &n);

    printf("Enter adjacency matrix (use 9999 for no edge):\n");
    for (i = 0; i < n; i++) {
        for (j = 0; j < n; j++) {
            scanf("%d", &graph[i][j]);
            if (graph[i][j] != 9999 && i < j) {
                edges[edgeCount].u = i;
                edges[edgeCount].v = j;
                edges[edgeCount].cost = graph[i][j];
                edgeCount++;
            }
        }
    }

    kruskal(edges, edgeCount, n);

    return 0;
}

