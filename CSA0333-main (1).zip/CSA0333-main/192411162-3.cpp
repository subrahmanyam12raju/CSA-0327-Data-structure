#include <stdio.h>

int main() {
    int n;
    unsigned long long fact = 1;
    printf("Enter a non-negative integer: ");
    scanf("%d", &n);

    if (n < 0) {
        printf("Error! Factorial of a negative number doesn't exist.\n");
        return 1;
    }
    for (int i = 1; i <= n; ++i) {
        fact *= i;
    }

    printf("%d! = %llu\n", n, fact);
    return 0;
}
