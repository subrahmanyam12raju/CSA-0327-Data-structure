#include <stdio.h>

#define SIZE 100

int array[SIZE];
int n = 0;

void display() {
    if (n == 0) {
        printf("Array is empty.\n");
        return;
    }
    printf("Array elements: ");
    for (int i = 0; i < n; i++) {
        printf("%d ", array[i]);
    }
    printf("\n");
}

void insert(int pos, int value) {
    if (n >= SIZE) {
        printf("Array is full.\n");
        return;
    }
    if (pos < 0 || pos > n) {
        printf("Invalid position.\n");
        return;
    }
    for (int i = n; i > pos; i--) {
        array[i] = array[i - 1];
    }
    array[pos] = value;
    n++;
    printf("Inserted %d at position %d\n", value, pos);
}

void deleteAt(int pos) {
    if (n == 0) {
        printf("Array is empty.\n");
        return;
    }
    if (pos < 0 || pos >= n) {
        printf("Invalid position.\n");
        return;
    }
    printf("Deleted %d from position %d\n", array[pos], pos);
    for (int i = pos; i < n - 1; i++) {
        array[i] = array[i + 1];
    }
    n--;
}

int main() {
    int choice, value, pos;
    while (1) {
        printf("\n1. Insert\n2. Delete\n3. Display\n4. Exit\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);
        switch (choice) {
            case 1:
                printf("Enter position (0 to %d): ", n);
                scanf("%d", &pos);
                printf("Enter value: ");
                scanf("%d", &value);
                insert(pos, value);
                break;
            case 2:
                printf("Enter position to delete (0 to %d): ", n - 1);
                scanf("%d", &pos);
                deleteAt(pos);
                break;
            case 3:
                display();
                break;
            case 4:
                return 0;
            default:
                printf("Invalid choice.\n");
        }
    }
}

